# FoodNest - Backend + Frontend

Recipe sharing community. Node.js backend with a SQLite database.
**No `npm install` needed** - it uses only Node's built-in modules.

## Requirements
- Node.js **22.13 or newer** (`node -v` to check). Download from https://nodejs.org

## Run it
```bash
cd foodnest-backend
node server.js
```
Open http://localhost:3000

Default admin (created automatically on the first run):
- Email: `admin@foodnest.com`
- Password: `admin123`

The database is saved in `data/foodnest.db`. Delete the `data` folder to start fresh.
You will see an "ExperimentalWarning: SQLite" message - this is normal.

## Settings (environment variables, all optional)
| Variable | Default | Meaning |
|---|---|---|
| `PORT` | 3000 | Port number |
| `HOST` | 127.0.0.1 | Use `0.0.0.0` on a hosting service / to open from your phone on the same Wi-Fi |
| `ADMIN_EMAIL` | admin@foodnest.com | Admin email created on first run |
| `ADMIN_PASSWORD` | admin123 | Admin password created on first run - **change this on a real server** |
| `DATA_DIR` | ./data | Where the database file is kept |
| `COOKIE_SECURE` | (off) | Set to `1` when the site runs on https |

Example: `ADMIN_PASSWORD=MyStrongPass PORT=8080 node server.js`
(Windows PowerShell: `$env:ADMIN_PASSWORD="MyStrongPass"; node server.js`)

## Files
```
server.js          the whole backend (API + database + static file server)
public/index.html  the frontend (same design, now uses the API)
data/              created automatically - the SQLite database
```

## API
All replies are JSON. Errors look like `{ "error": "message" }`.
Login uses an HttpOnly cookie, so the browser sends it automatically.

| Method | URL | Who | What it does |
|---|---|---|---|
| POST | /api/register | anyone | Create account `{name, email, password}` |
| POST | /api/login | anyone | Login `{email, password}` |
| POST | /api/logout | anyone | Logout |
| GET | /api/me | anyone | Current user (or `null`) |
| GET | /api/recipes?search=&category=&cuisine=&time= | logged in | List / search / filter recipes |
| POST | /api/recipes | logged in | Add recipe |
| PUT | /api/recipes/:id | owner or admin | Edit recipe |
| DELETE | /api/recipes/:id | owner or admin | Delete recipe |
| GET | /api/requests | logged in | Own requests (admin: all requests) |
| POST | /api/requests | logged in | Request a dish `{dish, notes}` |
| DELETE | /api/requests/:id | owner | Cancel (only while Pending) |
| PATCH | /api/requests/:id | admin | Set status `{status: "Approved" / "Rejected" / "Pending"}` |
| GET | /api/users | admin | All users with recipe counts |
| PATCH | /api/users/:id/role | admin | Change role `{role: "user" / "admin"}` |
| DELETE | /api/users/:id | admin | Delete user + their recipes and requests |
| GET | /api/stats | admin | Dashboard numbers |
| GET | /api/reports | admin | Data for the Reports page |

## Security built in
- Passwords stored as salted **scrypt** hashes (never plain text)
- Random session tokens in HttpOnly + SameSite=Strict cookies (only a hash of the token is stored)
- Role checks on the server (hiding buttons in the frontend is not enough)
- All input validated again on the server; SQL uses prepared statements (no SQL injection)
- Login blocked for 15 minutes after 10 wrong passwords
- Cross-site request check, request size limit, basic security headers

## Putting it online
Use any host that runs Node (Render, Railway, a VPS...). Set `HOST=0.0.0.0`,
`COOKIE_SECURE=1` (needs https), `ADMIN_PASSWORD`, and keep `DATA_DIR` on a persistent disk,
otherwise the database is lost on every redeploy.
