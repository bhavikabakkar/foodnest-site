"use strict";
/* =====================================================
   FOODNEST BACKEND
   - Node.js (built-in modules only, no npm install needed)
   - SQLite database (built into Node 22.13+ as "node:sqlite")
   - Serves the frontend from /public and the API from /api/*

   Sections: 1 Config | 2 Database | 3 Helpers | 4 Auth helpers
             5 Validation | 6 Routes | 7 Server
   ===================================================== */

const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { promisify } = require("node:util");
const { DatabaseSync } = require("node:sqlite");

const scrypt = promisify(crypto.scrypt);

/* ---------- 1. CONFIG ---------- */
const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || "127.0.0.1";          // use HOST=0.0.0.0 on a hosting service
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const PUBLIC_DIR = path.join(__dirname, "public");
const SESSION_DAYS = 7;
const COOKIE_NAME = "foodnest_session";
const SECURE_COOKIE = process.env.COOKIE_SECURE === "1"; // set COOKIE_SECURE=1 when using https
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || "admin@foodnest.com").toLowerCase();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";
const MAX_BODY_BYTES = 100 * 1024;

const CATEGORIES = ["Breakfast", "Lunch", "Dinner", "Snack", "Dessert", "Drink"];
const CUISINES = ["Indian", "Italian", "Chinese", "Mexican", "American", "Other"];
const STATUSES = ["Pending", "Approved", "Rejected"];
const TIME_GROUPS = [
  { label: "Quick (under 15 min)", min: 1, max: 14 },
  { label: "Medium (15-30 min)", min: 15, max: 30 },
  { label: "Long (31-60 min)", min: 31, max: 60 },
  { label: "Very long (over 60 min)", min: 61, max: 1000000 }
];
function timeGroupOf(minutes) {
  return TIME_GROUPS.find(function (g) { return minutes >= g.min && minutes <= g.max; }).label;
}

/* ---------- 2. DATABASE ---------- */
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, "foodnest.db"));
db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS recipes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title        TEXT NOT NULL,
    category     TEXT NOT NULL,
    cuisine      TEXT NOT NULL,
    time_minutes INTEGER NOT NULL CHECK (time_minutes BETWEEN 1 AND 1440),
    ingredients  TEXT NOT NULL,
    steps        TEXT NOT NULL,
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at   TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS requests (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    dish       TEXT NOT NULL,
    notes      TEXT NOT NULL DEFAULT '',
    status     TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'Approved', 'Rejected')),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_recipes_user ON recipes(user_id);
  CREATE INDEX IF NOT EXISTS idx_requests_user ON requests(user_id);
`);

/* ---------- 3. HELPERS ---------- */
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": Buffer.byteLength(body),
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function readBody(req) {
  return new Promise(function (resolve, reject) {
    const chunks = [];
    let size = 0;
    req.on("data", function (chunk) {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(new HttpError(413, "Request is too large."));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", function () {
      if (size === 0) return resolve({});
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString("utf8"));
        if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("not an object");
        resolve(parsed);
      } catch (e) {
        reject(new HttpError(400, "Request body must be valid JSON."));
      }
    });
    req.on("error", reject);
  });
}

function parseCookies(header) {
  const out = {};
  (header || "").split(";").forEach(function (part) {
    const i = part.indexOf("=");
    if (i > -1) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  });
  return out;
}

function str(value) {
  return typeof value === "string" ? value.trim() : "";
}

function escapeLike(text) {
  return text.replace(/[\\%_]/g, "\\$&");
}

function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email, role: u.role };
}

function parseId(text) {
  const id = Number(text);
  if (!Number.isInteger(id) || id < 1) throw new HttpError(404, "Not found.");
  return id;
}

/* ---------- 4. AUTH HELPERS (passwords + sessions) ---------- */
// Passwords are never stored as plain text. We store "salt:hash" made with scrypt.
async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt, 64);
  return salt.toString("hex") + ":" + key.toString("hex");
}

async function verifyPassword(password, stored) {
  const parts = String(stored).split(":");
  if (parts.length !== 2) return false;
  const salt = Buffer.from(parts[0], "hex");
  const expected = Buffer.from(parts[1], "hex");
  const actual = await scrypt(password, salt, expected.length);
  return crypto.timingSafeEqual(actual, expected);
}

// Used when the email does not exist, so login takes the same time either way
const DUMMY_HASH = (function () {
  const salt = crypto.randomBytes(16);
  return salt.toString("hex") + ":" + crypto.scryptSync("dummy-password", salt, 64).toString("hex");
})();

function sha256(text) {
  return crypto.createHash("sha256").update(text).digest("hex");
}

function cookieString(value, maxAgeSeconds) {
  let c = COOKIE_NAME + "=" + value + "; HttpOnly; SameSite=Strict; Path=/; Max-Age=" + maxAgeSeconds;
  if (SECURE_COOKIE) c += "; Secure";
  return c;
}

function startSession(res, userId) {
  const token = crypto.randomBytes(32).toString("hex");
  const expires = Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000;
  db.prepare("INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)").run(sha256(token), userId, expires);
  res.setHeader("Set-Cookie", cookieString(token, SESSION_DAYS * 24 * 60 * 60));
}

function endSession(req, res) {
  const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
  if (token) db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(sha256(token));
  res.setHeader("Set-Cookie", cookieString("", 0));
}

function getSessionUser(req) {
  const token = parseCookies(req.headers.cookie)[COOKIE_NAME];
  if (!token) return null;
  return db.prepare(
    "SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?"
  ).get(sha256(token), Date.now()) || null;
}

// Simple brute-force protection: 10 wrong passwords per email+IP, then wait 15 minutes
const loginFails = new Map();
const MAX_FAILS = 10;
const FAIL_WINDOW_MS = 15 * 60 * 1000;
function isLockedOut(key) {
  const f = loginFails.get(key);
  if (!f) return false;
  if (Date.now() > f.resetAt) { loginFails.delete(key); return false; }
  return f.count >= MAX_FAILS;
}
function recordFail(key) {
  const f = loginFails.get(key);
  if (!f || Date.now() > f.resetAt) loginFails.set(key, { count: 1, resetAt: Date.now() + FAIL_WINDOW_MS });
  else f.count++;
}

/* ---------- 5. VALIDATION (same rules as the frontend, checked again on the server) ---------- */
function validateRecipe(b) {
  const title = str(b.title);
  const category = str(b.category);
  const cuisine = str(b.cuisine);
  const time = Number(b.time);
  const ingredients = str(b.ingredients);
  const steps = str(b.steps);

  if (title.length < 3) throw new HttpError(400, "Title must have at least 3 letters.");
  if (title.length > 100) throw new HttpError(400, "Title is too long (max 100 characters).");
  if (CATEGORIES.indexOf(category) === -1) throw new HttpError(400, "Please choose a valid category.");
  if (CUISINES.indexOf(cuisine) === -1) throw new HttpError(400, "Please choose a valid cuisine.");
  if (!Number.isInteger(time) || time < 1 || time > 1440) throw new HttpError(400, "Enter cooking time between 1 and 1440 minutes.");
  const lines = ingredients.split("\n").filter(function (l) { return l.trim() !== ""; });
  if (lines.length < 2) throw new HttpError(400, "Add at least 2 ingredients (one per line).");
  if (ingredients.length > 2000) throw new HttpError(400, "Ingredients are too long (max 2000 characters).");
  if (steps.length < 10) throw new HttpError(400, "Please write the steps (at least 10 characters).");
  if (steps.length > 5000) throw new HttpError(400, "Steps are too long (max 5000 characters).");

  return { title: title, category: category, cuisine: cuisine, time: time, ingredients: ingredients, steps: steps };
}

/* ---------- 6. ROUTES ---------- */
const routes = [];
// access: "public" (anyone) | "user" (logged in) | "admin" (admins only)
function route(method, pattern, access, handler) {
  const keys = [];
  const regex = new RegExp("^" + pattern.replace(/:(\w+)/g, function (_, k) { keys.push(k); return "([^/]+)"; }) + "$");
  routes.push({ method: method, regex: regex, keys: keys, access: access, handler: handler });
}

/* ----- Auth ----- */
route("POST", "/api/register", "public", async function (ctx) {
  const name = str(ctx.body.name);
  const email = str(ctx.body.email).toLowerCase();
  const password = typeof ctx.body.password === "string" ? ctx.body.password : "";

  if (name.length < 2) throw new HttpError(400, "Name must have at least 2 letters.");
  if (name.length > 50) throw new HttpError(400, "Name is too long (max 50 characters).");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 100) throw new HttpError(400, "Enter a valid email.");
  if (password.length < 6) throw new HttpError(400, "Password must have at least 6 characters.");
  if (password.length > 100) throw new HttpError(400, "Password is too long (max 100 characters).");

  if (db.prepare("SELECT id FROM users WHERE email = ?").get(email)) {
    throw new HttpError(409, "This email is already registered.");
  }
  const hash = await hashPassword(password);
  let id;
  try {
    id = db.prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'user')").run(name, email, hash).lastInsertRowid;
  } catch (e) {
    throw new HttpError(409, "This email is already registered.");
  }
  startSession(ctx.res, Number(id));
  json(ctx.res, 201, { user: publicUser(db.prepare("SELECT * FROM users WHERE id = ?").get(id)) });
});

route("POST", "/api/login", "public", async function (ctx) {
  const email = str(ctx.body.email).toLowerCase();
  const password = typeof ctx.body.password === "string" ? ctx.body.password : "";
  if (email === "" || password === "") throw new HttpError(400, "Please fill in both fields.");
  if (password.length > 100) throw new HttpError(401, "Wrong email or password.");

  const key = ctx.req.socket.remoteAddress + "|" + email;
  if (isLockedOut(key)) throw new HttpError(429, "Too many failed attempts. Please try again in a few minutes.");

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  const ok = await verifyPassword(password, user ? user.password_hash : DUMMY_HASH);
  if (!user || !ok) {
    recordFail(key);
    throw new HttpError(401, "Wrong email or password.");
  }
  loginFails.delete(key);
  startSession(ctx.res, user.id);
  json(ctx.res, 200, { user: publicUser(user) });
});

route("POST", "/api/logout", "public", function (ctx) {
  endSession(ctx.req, ctx.res);
  json(ctx.res, 200, { ok: true });
});

// Tells the frontend who is logged in (user is null when nobody is)
route("GET", "/api/me", "public", function (ctx) {
  return { user: ctx.user ? publicUser(ctx.user) : null };
});

route("GET", "/api/health", "public", function () {
  return { ok: true };
});

/* ----- Recipes ----- */
const RECIPE_SELECT =
  "SELECT r.id, r.title, r.category, r.cuisine, r.time_minutes AS time, r.ingredients, r.steps, " +
  "r.user_id AS userId, u.name AS authorName FROM recipes r JOIN users u ON u.id = r.user_id";

function recipeForClient(row, user) {
  row.canEdit = (row.userId === user.id || user.role === "admin");
  return row;
}

route("GET", "/api/recipes", "user", function (ctx) {
  const where = [];
  const args = [];

  const search = str(ctx.query.get("search"));
  if (search) {
    const like = "%" + escapeLike(search) + "%";
    where.push("(r.title LIKE ? ESCAPE '\\' OR r.ingredients LIKE ? ESCAPE '\\' OR r.cuisine LIKE ? ESCAPE '\\')");
    args.push(like, like, like);
  }
  const category = str(ctx.query.get("category"));
  if (category) { where.push("r.category = ?"); args.push(category); }
  const cuisine = str(ctx.query.get("cuisine"));
  if (cuisine) { where.push("r.cuisine = ?"); args.push(cuisine); }
  const time = str(ctx.query.get("time"));
  if (time) {
    const group = TIME_GROUPS.find(function (g) { return g.label === time; });
    if (!group) throw new HttpError(400, "Unknown cooking time filter.");
    where.push("r.time_minutes BETWEEN ? AND ?");
    args.push(group.min, group.max);
  }

  const sql = RECIPE_SELECT + (where.length ? " WHERE " + where.join(" AND ") : "") + " ORDER BY r.id";
  const rows = db.prepare(sql).all(...args).map(function (r) { return recipeForClient(r, ctx.user); });
  return { recipes: rows };
});

route("POST", "/api/recipes", "user", function (ctx) {
  const r = validateRecipe(ctx.body);
  const id = db.prepare(
    "INSERT INTO recipes (user_id, title, category, cuisine, time_minutes, ingredients, steps) VALUES (?, ?, ?, ?, ?, ?, ?)"
  ).run(ctx.user.id, r.title, r.category, r.cuisine, r.time, r.ingredients, r.steps).lastInsertRowid;
  const row = db.prepare(RECIPE_SELECT + " WHERE r.id = ?").get(id);
  json(ctx.res, 201, { recipe: recipeForClient(row, ctx.user) });
});

function getEditableRecipe(id, user) {
  const recipe = db.prepare("SELECT * FROM recipes WHERE id = ?").get(id);
  if (!recipe) throw new HttpError(404, "Recipe not found.");
  // Owner can change their own recipes. Admin can change all.
  if (recipe.user_id !== user.id && user.role !== "admin") throw new HttpError(403, "You can only change your own recipes.");
  return recipe;
}

route("PUT", "/api/recipes/:id", "user", function (ctx) {
  const id = parseId(ctx.params.id);
  getEditableRecipe(id, ctx.user);
  const r = validateRecipe(ctx.body);
  db.prepare(
    "UPDATE recipes SET title = ?, category = ?, cuisine = ?, time_minutes = ?, ingredients = ?, steps = ?, updated_at = datetime('now') WHERE id = ?"
  ).run(r.title, r.category, r.cuisine, r.time, r.ingredients, r.steps, id);
  const row = db.prepare(RECIPE_SELECT + " WHERE r.id = ?").get(id);
  return { recipe: recipeForClient(row, ctx.user) };
});

route("DELETE", "/api/recipes/:id", "user", function (ctx) {
  const id = parseId(ctx.params.id);
  getEditableRecipe(id, ctx.user);
  db.prepare("DELETE FROM recipes WHERE id = ?").run(id);
  return { ok: true };
});

/* ----- Recipe requests ----- */
const REQUEST_SELECT =
  "SELECT q.id, q.dish, q.notes, q.status, q.user_id AS userId, u.name AS userName " +
  "FROM requests q JOIN users u ON u.id = q.user_id";

// Normal users see only their own requests. Admin sees everyone's.
route("GET", "/api/requests", "user", function (ctx) {
  const rows = ctx.user.role === "admin"
    ? db.prepare(REQUEST_SELECT + " ORDER BY q.id").all()
    : db.prepare(REQUEST_SELECT + " WHERE q.user_id = ? ORDER BY q.id").all(ctx.user.id);
  return { requests: rows };
});

route("POST", "/api/requests", "user", function (ctx) {
  const dish = str(ctx.body.dish);
  const notes = str(ctx.body.notes);
  if (dish.length < 3) throw new HttpError(400, "Dish name must have at least 3 letters.");
  if (dish.length > 100) throw new HttpError(400, "Dish name is too long (max 100 characters).");
  if (notes.length > 300) throw new HttpError(400, "Notes are too long (max 300 characters).");

  const same = db.prepare(
    "SELECT id FROM requests WHERE user_id = ? AND lower(dish) = lower(?) AND status = 'Pending'"
  ).get(ctx.user.id, dish);
  if (same) throw new HttpError(409, "You already requested this dish.");

  const id = db.prepare("INSERT INTO requests (user_id, dish, notes) VALUES (?, ?, ?)").run(ctx.user.id, dish, notes).lastInsertRowid;
  json(ctx.res, 201, { request: db.prepare(REQUEST_SELECT + " WHERE q.id = ?").get(id) });
});

// User cancels their own request (only while it is still Pending)
route("DELETE", "/api/requests/:id", "user", function (ctx) {
  const id = parseId(ctx.params.id);
  const request = db.prepare("SELECT * FROM requests WHERE id = ? AND user_id = ?").get(id, ctx.user.id);
  if (!request) throw new HttpError(404, "Request not found.");
  if (request.status !== "Pending") throw new HttpError(400, "Only pending requests can be cancelled.");
  db.prepare("DELETE FROM requests WHERE id = ?").run(id);
  return { ok: true };
});

// Admin approves / rejects
route("PATCH", "/api/requests/:id", "admin", function (ctx) {
  const id = parseId(ctx.params.id);
  const status = str(ctx.body.status);
  if (STATUSES.indexOf(status) === -1) throw new HttpError(400, "Status must be Pending, Approved or Rejected.");
  const result = db.prepare("UPDATE requests SET status = ? WHERE id = ?").run(status, id);
  if (result.changes === 0) throw new HttpError(404, "Request not found.");
  return { request: db.prepare(REQUEST_SELECT + " WHERE q.id = ?").get(id) };
});

/* ----- Admin: users ----- */
route("GET", "/api/users", "admin", function () {
  const rows = db.prepare(
    "SELECT u.id, u.name, u.email, u.role, (SELECT COUNT(*) FROM recipes r WHERE r.user_id = u.id) AS recipeCount " +
    "FROM users u ORDER BY u.id"
  ).all();
  return { users: rows };
});

function getOtherUser(id, admin) {
  if (id === admin.id) throw new HttpError(400, "You cannot change or delete your own account.");
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(id);
  if (!user) throw new HttpError(404, "User not found.");
  return user;
}

route("PATCH", "/api/users/:id/role", "admin", function (ctx) {
  const id = parseId(ctx.params.id);
  getOtherUser(id, ctx.user);
  const role = str(ctx.body.role);
  if (role !== "user" && role !== "admin") throw new HttpError(400, "Role must be user or admin.");
  db.prepare("UPDATE users SET role = ? WHERE id = ?").run(role, id);
  return { ok: true };
});

// Deleting a user also deletes their recipes, requests and sessions (ON DELETE CASCADE)
route("DELETE", "/api/users/:id", "admin", function (ctx) {
  const id = parseId(ctx.params.id);
  getOtherUser(id, ctx.user);
  db.prepare("DELETE FROM users WHERE id = ?").run(id);
  return { ok: true };
});

/* ----- Admin: dashboard & reports ----- */
route("GET", "/api/stats", "admin", function () {
  const count = function (sql) { return db.prepare(sql).get().n; };
  return {
    users: count("SELECT COUNT(*) AS n FROM users"),
    recipes: count("SELECT COUNT(*) AS n FROM recipes"),
    requests: count("SELECT COUNT(*) AS n FROM requests"),
    pending: count("SELECT COUNT(*) AS n FROM requests WHERE status = 'Pending'")
  };
});

route("GET", "/api/reports", "admin", function () {
  const recipes = db.prepare("SELECT category, cuisine, time_minutes AS time FROM recipes").all();

  function average(list) {
    if (list.length === 0) return null;
    return list.reduce(function (sum, r) { return sum + r.time; }, 0) / list.length;
  }

  const requestCounts = db.prepare("SELECT status, COUNT(*) AS n FROM requests GROUP BY status").all();
  const perUser = db.prepare(
    "SELECT u.name, (SELECT COUNT(*) FROM recipes r WHERE r.user_id = u.id) AS recipes FROM users u ORDER BY u.id"
  ).all();

  return {
    perCategory: CATEGORIES.map(function (c) {
      return { category: c, count: recipes.filter(function (r) { return r.category === c; }).length };
    }),
    perCuisine: CUISINES.map(function (c) {
      const list = recipes.filter(function (r) { return r.cuisine === c; });
      return { cuisine: c, count: list.length, avgTime: average(list) };
    }),
    overall: { count: recipes.length, avgTime: average(recipes) },
    perTimeGroup: TIME_GROUPS.map(function (g) {
      return { group: g.label, count: recipes.filter(function (r) { return timeGroupOf(r.time) === g.label; }).length };
    }),
    requestsByStatus: STATUSES.map(function (s) {
      const found = requestCounts.find(function (x) { return x.status === s; });
      return { status: s, count: found ? found.n : 0 };
    }),
    perUser: perUser
  };
});

/* ---------- 7. SERVER ---------- */
const MIME = {
  ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".json": "application/json", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml", ".ico": "image/x-icon", ".webp": "image/webp"
};

function serveStatic(req, res, pathname) {
  if (req.method !== "GET" && req.method !== "HEAD") return json(res, 405, { error: "Method not allowed." });
  let rel;
  try { rel = decodeURIComponent(pathname); } catch (e) { return json(res, 400, { error: "Bad request." }); }
  if (rel === "/") rel = "/index.html";

  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (file.indexOf(PUBLIC_DIR + path.sep) !== 0) return json(res, 404, { error: "Not found." });

  fs.readFile(file, function (err, data) {
    if (err) return json(res, 404, { error: "Not found." });
    res.writeHead(200, {
      "Content-Type": MIME[path.extname(file).toLowerCase()] || "application/octet-stream",
      "Content-Length": data.length,
      "Cache-Control": "no-cache"
    });
    res.end(req.method === "HEAD" ? undefined : data);
  });
}

async function handleApi(req, res, url) {
  // Block requests coming from other websites (extra CSRF protection on top of SameSite cookies)
  if (req.method !== "GET" && req.method !== "HEAD" && req.headers.origin) {
    let originHost = "";
    try { originHost = new URL(req.headers.origin).host; } catch (e) { /* ignore */ }
    if (originHost !== req.headers.host) throw new HttpError(403, "Cross-site requests are not allowed.");
  }

  let pathMatched = false;
  for (const r of routes) {
    const m = r.regex.exec(url.pathname);
    if (!m) continue;
    pathMatched = true;
    if (r.method !== req.method) continue;

    const user = getSessionUser(req);
    if (r.access !== "public" && !user) throw new HttpError(401, "Please log in first.");
    if (r.access === "admin" && user.role !== "admin") throw new HttpError(403, "Admins only.");

    const params = {};
    r.keys.forEach(function (k, i) { params[k] = m[i + 1]; });
    const body = (req.method === "GET" || req.method === "HEAD" || req.method === "DELETE") ? {} : await readBody(req);

    const result = await r.handler({ req: req, res: res, user: user, params: params, query: url.searchParams, body: body });
    if (result !== undefined && !res.writableEnded) json(res, 200, result);
    return;
  }
  throw new HttpError(pathMatched ? 405 : 404, pathMatched ? "Method not allowed." : "Not found.");
}

const server = http.createServer(async function (req, res) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "same-origin");
  res.setHeader("Content-Security-Policy",
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'");

  try {
    const url = new URL(req.url, "http://localhost");
    if (url.pathname.startsWith("/api/")) await handleApi(req, res, url);
    else serveStatic(req, res, url.pathname);
  } catch (err) {
    if (res.headersSent) return;
    if (err instanceof HttpError) json(res, err.status, { error: err.message });
    else {
      console.error(err);
      json(res, 500, { error: "Something went wrong on the server." });
    }
  }
});

// Create the default admin the first time (only when there are no users yet)
async function seedIfEmpty() {
  if (db.prepare("SELECT COUNT(*) AS n FROM users").get().n > 0) return;
  const hash = await hashPassword(ADMIN_PASSWORD);
  const adminId = db.prepare("INSERT INTO users (name, email, password_hash, role) VALUES ('Admin', ?, ?, 'admin')").run(ADMIN_EMAIL, hash).lastInsertRowid;
  db.prepare(
    "INSERT INTO recipes (user_id, title, category, cuisine, time_minutes, ingredients, steps) VALUES (?, ?, ?, ?, ?, ?, ?)"
  ).run(adminId, "Masala Maggi", "Snack", "Indian", 10,
        "Maggi noodles\nOnion\nTomato\nMasala",
        "Boil the noodles.\nCook onion and tomato.\nMix everything with masala.");
  console.log("Created default admin: " + ADMIN_EMAIL);
  if (ADMIN_PASSWORD === "admin123") {
    console.log("WARNING: the admin password is the default one. Set ADMIN_PASSWORD before the first run on a real server.");
  }
}

// Remove expired sessions every hour
setInterval(function () {
  db.prepare("DELETE FROM sessions WHERE expires_at < ?").run(Date.now());
}, 60 * 60 * 1000).unref();

seedIfEmpty().then(function () {
  server.listen(PORT, HOST, function () {
    console.log("FoodNest is running at http://" + (HOST === "0.0.0.0" ? "localhost" : HOST) + ":" + PORT);
  });
});

function shutdown() {
  server.close();
  try { db.close(); } catch (e) { /* ignore */ }
  process.exit(0);
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
